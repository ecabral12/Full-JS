import express from 'express';

export class ExpressServer{
    private express = express();

    constructor(private port: String){}

    //function
    bootstrap(): void{
        this.express.listen(this.port,() => {
            console.log(`> Listening on port ${this.port}`);
        })
    }
}
